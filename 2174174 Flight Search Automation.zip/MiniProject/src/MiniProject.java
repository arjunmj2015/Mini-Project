import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.FileHandler;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class MiniProject {
	 WebDriver driver;
	
	public void DriverSetup() {
		String browser = null;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Browser Name:");
		browser=sc.nextLine();
		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32 (3)\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\chromedriver_win32 (3)\\geckodriver.exe");
			driver= new FirefoxDriver();
			driver.manage().window().maximize();
		}
		
	}
	
	public void search() {
		 String url="https://www.air.irctc.co.in/";
		 driver.get(url);
	}
	public void origin() {
		
		//driver.findElement(By.xpath("//*[@id=\"stationFrom\"]")).click();
		WebElement Origin=driver.findElement(By.xpath("//*[@id=\"stationFrom\"]"));
		Origin.sendKeys("Hyd");
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Origin.sendKeys(Keys.ARROW_DOWN);
		Origin.sendKeys(Keys.ENTER);
	}
	public void destination() {
		WebElement Destination=driver.findElement(By.xpath("//*[@id=\"stationTo\"]"));
		Destination.sendKeys("Pune");
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Destination.sendKeys(Keys.ARROW_DOWN);
		Destination.sendKeys(Keys.ENTER);
	}
	
	public void dateSearch() {
		driver.findElement(By.xpath("//input[@id='originDate']")).click();

	    driver.findElement(By.xpath("//*[@id=\"carouselExampleInterval\"]/div[1]/div/div/div[2]/form/div[3]/datepickermodifi/div/div[2]/div[2]/table/tbody/tr[1]/td[7]")).click();
	}
	public void travelClass() {
		driver.findElement(By.xpath("//input[@class='form-control']")).click();
		Select select=new Select(driver.findElement(By.id("travelClass")));
		select.selectByVisibleText("Business");
		driver.findElement(By.id("noOfpaxEtc")).click();
		
	}
	public void Search() {
		driver.findElement(By.xpath("//button[@class='btn btn-md yellow-gradient home-btn']")).click();
		
	}
	public void screenshot()
	{
	File file= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(file,new File("C:\\Users\\arjun\\eclipse-workspace\\SeleniumProjects\\Screenshot\\screenshot.jpg"));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			driver.close();
			
			
	System.out.println("Screenshot  has been taken successfully");

	}
	
		
	public static void main(String[] args) throws InterruptedException {
		
		MiniProject obj= new MiniProject();
		
		obj.DriverSetup();
		obj.search();
		obj.origin();
		obj.destination();
		obj.dateSearch();
		obj.travelClass();
		obj.Search();
		Thread.sleep(8000);
		obj.screenshot();
		
		// ARJUN M J-----2174174
	}
}

		
	
